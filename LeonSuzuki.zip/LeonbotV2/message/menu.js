exports.menu = (prefix) => {
  let a = '*妥︎⃟🔖*'
  let b = '```'
  let c = '⬡'
  let d = '⬢'
  let e = '⬣'
  let o = 0
  return `${b}🌹【 LIST MENU BOT 】🌹${b}

    ${b}🌹【 OWNER MENU 】🌹${b}
${a} ${prefix}broadcast
${a} ${prefix}setprefix
${a} ${prefix}public
${a} ${prefix}self
${a} ${prefix}addcmd
${a} ${prefix}delcmd
${a} ${prefix}setfake
${a} ${prefix}setfakeimage
${a} ${prefix}setthumb
${a} ${prefix}leaveall
${a} ${prefix}leavegroup
${a} ${prefix}autoread
${a} ${prefix}deletepc
${a} ${prefix}join
${a} ${prefix}setpresence
${a} ${prefix}setppbot
${a} ${prefix}exif
${a} ${prefix}online
${a} ${prefix}offline

   ${b}🌹【 GROUP MENU 】🌹${b}
${a} ${prefix}add
${a} ${prefix}kick
${a} ${prefix}promote
${a} ${prefix}demote
${a} ${prefix}inspect
${a} ${prefix}setppgroup
${a} ${prefix}hidetag
${a} ${prefix}tagall
${a} ${prefix}welcome
${a} ${prefix}antilink
${a} ${prefix}totag
${a} ${prefix}linkgroup
${a} ${prefix}sider
${a} ${prefix}opengc
${a} ${prefix}closegc
${a} ${prefix}groupinfo
${a} ${prefix}grouplist

   ${b}🌹【 DOWNLOAD MENU 】🌹${b}
${a} ${prefix}google
${a} ${prefix}pinterest
${a} ${prefix}ytsearch
${a} ${prefix}play
${a} ${prefix}ytmp3
${a} ${prefix}ytmp4
${a} ${prefix}tiktok
${a} ${prefix}tiktokaudio
${a} ${prefix}mediafire
${a} ${prefix}instagram

   ${b}🌹【 GAME MENU 】🌹${b}
${a} ${prefix}tictactoe
${a} ${prefix}gelud
${a} ${prefix}slot
${a} ${prefix}suit

   ${b}🌹【 NSFW MENU 】🌹${b}
${a} ${prefix}waifu
${a} ${prefix}loli
${a} ${prefix}pussy
${a} ${prefix}neko
${a} ${prefix}lesbian
${a} ${prefix}kuni
${a} ${prefix}cumsluts
${a} ${prefix}classic
${a} ${prefix}boobs
${a} ${prefix}anal
${a} ${prefix}avatar
${a} ${prefix}yuri
${a} ${prefix}trap
${a} ${prefix}tits
${a} ${prefix}kitsune
${a} ${prefix}holo
${a} ${prefix}keta
${a} ${prefix}hentai
${a} ${prefix}futanari
${a} ${prefix}femdom
${a} ${prefix}feet
${a} ${prefix}ero
${a} ${prefix}kemonomimi
${a} ${prefix}spank
${a} ${prefix}cumarts
${a} ${prefix}bokep
${a} ${prefix}bj
${a} ${prefix}blowjob
${a} ${prefix}girlsolo
${a} ${prefix}holoero
${a} ${prefix}erofeet
${a} ${prefix}erokitsune
${a} ${prefix}eroneko
${a} ${prefix}eroyuri
${a} ${prefix}erokemonomimi

   ${b}🌹【 STICKER MENU 】🌹${b}
${a} ${prefix}attp
${a} ${prefix}ttp
${a} ${prefix}sticker
${a} ${prefix}swm
${a} ${prefix}szoom
${a} ${prefix}gawrgura
${a} ${prefix}doge
${a} ${prefix}patrick
${a} ${prefix}take
${a} ${prefix}toimg
${a} ${prefix}tomp4
${a} ${prefix}tomp3

   ${b}🌹【 STORY MENU 】🌹${b}
${a} ${prefix}upswteks
${a} ${prefix}upswimage
${a} ${prefix}upswvideo

   ${b}🌹【 TOURL MENU 】🌹${b}
${a} ${prefix}tourl
${a} ${prefix}imagetorul
${a} ${prefix}imgtourl
${a} ${prefix}audiotourl
${a} ${prefix}videotourl
${a} ${prefix}stickertourl
${a} ${prefix}stikertourl
${a} ${prefix}tolink

   ${b}🌹【 OTHERS MENU 】🌹${b}
${a} ${prefix}owner
${a} ${prefix}rules
${a} ${prefix}script
${a} ${prefix}runtime
${a} ${prefix}speed
${a} ${prefix}delete
${a} ${prefix}cekapikey

*Note* : Bot Ini Sedang Dalam Pengembangan,
Well Not All Features Is Work
`
}